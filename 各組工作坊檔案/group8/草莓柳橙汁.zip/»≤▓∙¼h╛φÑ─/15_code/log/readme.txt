How log files are formated:

party:
[a,b,c,d,e]
a: Which election
b: Index of party (1,2)
c: COST (parameter)
d: platform of party
e: whether the party is elected (1) or not (0)

voters:
[a,b,c,d,e,formated]
a: Which election
b: Index of voter (1~1024)
c: COST (parameter)
d: whether one has voted (True) or abstained (False)
e: number of voters within one's neighborhood
f: number of abstainers within one's neighborhood