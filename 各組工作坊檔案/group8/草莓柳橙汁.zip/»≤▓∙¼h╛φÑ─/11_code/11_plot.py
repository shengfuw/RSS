#Replication simulations about
#Grund, T. (2014). Why your friends are more important and special than you
#think, Sociological Science,1, 128-140.

import numpy as np
import matplotlib.pyplot as plt 
import pandas as pd
from os import listdir
from os.path import isfile, isdir, join
import os

# p.137 figure 6

#path = 
#os.chdir(path)
df = pd.read_csv('friend_er_fd.csv')
df2 = pd.read_csv('friend_er_ran.csv')


all_data1 = [df2['a'], df['a']]
all_data2 = [df2['c'], df['c']]
all_data3 = [df2['e'], df['e']]



labels = ['Random', 'Friends']

fig, (ax1, ax2, ax3) = plt.subplots(nrows=1, ncols=3, figsize=(15, 4))

# rectangular box plot
bplot1 = ax1.boxplot(all_data1, vert=True, widths = 0.6, 
                     patch_artist=True,  # fill with color
                     labels=labels)  # will be used to label x-ticks
ax1.set_title('Corr (x, Degree) = 0.0')


bplot2 = ax2.boxplot(all_data2, vert=True, widths = 0.6,
                     patch_artist=True, labels=labels) 
ax2.set_title('Corr(x, Degree) = 0.4')

bplot3 = ax3.boxplot(all_data3, vert=True,  widths = 0.6, 
                     patch_artist=True, labels=labels)  
ax3.set_title('Corr (x, Degree) = 0.8')

# fill with colors
colors = ['white', 'lightblue']
for bplot in (bplot1, bplot2, bplot3):
    for patch, color in zip(bplot['boxes'], colors):
        patch.set_facecolor(color)


for ax in [ax1, ax2, ax3]:
    #ax.yaxis.grid(True)
    ax.set_ylabel('x')
    ax.set_ylim([-4,4])
plt.savefig("sim_er.png", format="png", bbox_inches='tight', dpi=100)
plt.show()